# Navbar with tooltip on hover

A Pen created on CodePen.io. Original URL: [https://codepen.io/havardob/pen/qBjbQya](https://codepen.io/havardob/pen/qBjbQya).

Icons by https://akaricons.com/ 